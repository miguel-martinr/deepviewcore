def process_frame(frame):
    pass